-Qual parte do código escrito deveria ser prioritariamente testada e por quê? 
Nome, Idade, Data e o campo de texto, ja que alguns campos não podem inserir letras, apenas numeros e em outros é inserido apenas letras.

-Quais ferramentas poderiam ser utilizadas para testar a parte do código sugerida? 
Eu utilizei o Visual Studio Code, mas o Visual Studio tambem poderia ser utilizado

-Qual estratégia de teste você considera ideal para ser utilizada neste cenário? 
Provavelmente um JUnit